//
//  SPICE6OutlineController.h
//  Application
//
//  Created by Joshua Nozzi on 9/16/13.
//  Copyright (c) 2013 Mario Roederer, Joshua Nozzi, Vaccine Research Center, NIAID. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "SPICE6Document.h"
#import "SPICE6QueryController.h"
#import "SPICE6DocumentViewController.h"
#import "SPICE6FigureCellView.h"
#import "SPICE6QueryGroupCellView.h"

@class SPICE6FigureCellView;

@interface SPICE6OutlineController : SPICE6DocumentViewController

#pragma mark Lifecycle

- (void)reloadData;

- (void)willBecomeInactive;

#pragma mark Selection

- (BOOL)isQueryGroupExpanded:(SPICE6QueryGroup *)queryGroup;

- (void)expandItemIfNeeded:(id)item;

#pragma mark Metrics

- (void)noteFigureCellViewMetricsChanged:(SPICE6FigureCellView *)figureCellView;

#pragma mark Mouse

- (NSMenu *)menuForAsset:(SPICE6Asset *)asset;

#pragma mark User Actions

- (IBAction)copy:(id)sender;

@end
